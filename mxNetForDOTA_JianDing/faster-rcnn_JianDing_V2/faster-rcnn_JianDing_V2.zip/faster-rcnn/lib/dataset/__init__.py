from imdb import IMDB
from pascal_voc import PascalVOC
from cityscape import CityScape
from coco import coco
from DOTA import DOTA_oriented,DOTA
from UCAS import UCAS
